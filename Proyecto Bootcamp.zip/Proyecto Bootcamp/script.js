// Inicializar el carrusel principal (Swiper 1)
const swiper1 = new Swiper('.mySwiper-1', {
    loop: true,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },
  });
  
  // Inicializar el carrusel de productos (Swiper 2)
  const swiper2 = new Swiper('.mySwiper-2', {
    slidesPerView: 1,
    spaceBetween: 10,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    breakpoints: {
      640: {
        slidesPerView: 2,
        spaceBetween: 20,
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 30,
      },
      1024: {
        slidesPerView: 4,
        spaceBetween: 40,
      },
    },
  });
  
  // Validar el formulario de contacto
  const form = document.querySelector('#formulario form');
  form.addEventListener('submit', (e) => {
    e.preventDefault(); // Evitar envío por defecto
    const nombre = form.nombre.value.trim();
    const apellido = form.apellido.value.trim();
    const correo = form.correo.value.trim();
    const mensaje = form.mensaje.value.trim();
  
    if (!nombre || !apellido || !correo || !mensaje) {
      alert('Por favor, completa todos los campos.');
      return;
    }
  
    // Validar correo electrónico
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(correo)) {
      alert('Por favor, ingresa un correo electrónico válido.');
      return;
    }
  
    alert('¡Gracias por contactarnos! Hemos recibido tu mensaje.');
    form.reset();
  });
  
  // Mostrar el menú responsive (opcional)
  const navBar = document.querySelector('.navBar');
  const toggleMenu = document.createElement('button');
  toggleMenu.textContent = '☰';
  toggleMenu.classList.add('toggle-menu');
  navBar.parentNode.insertBefore(toggleMenu, navBar);
  
  toggleMenu.addEventListener('click', () => {
    navBar.classList.toggle('visible');
  });